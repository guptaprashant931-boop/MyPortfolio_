const container =
document.getElementById(
  "projects-container"
);

async function loadProjects(){

  const response =
  await fetch(
    "http://127.0.0.1:8000/api/projects/"
  );

  const data =
  await response.json();

  const projects =
    data.results || data;

  projects.forEach(project=>{

    container.innerHTML += `

      <div class="card">

        <h2>
          ${project.title}
        </h2>

        <p>
          ${project.description}
        </p>

        <a href="${project.github_url}">
          GitHub
        </a>

      </div>

    `;
  });
}

loadProjects();